//  BoschUILibrary.h
//
//  Created by M-Way Solutions in behalf of Bosch GmbH on 24.11.17
//

#import <UIKit/UIKit.h>

//! Project version number for BoschUILibrary.
FOUNDATION_EXPORT double BoschUILibraryVersionNumber;

//! Project version string for BoschUILibrary.
FOUNDATION_EXPORT const unsigned char BoschUILibraryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BoschUILibrary/PublicHeader.h>
